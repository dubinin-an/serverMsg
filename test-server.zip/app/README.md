# Node.js Express & MongoDB: CRUD Rest APIs
## Project setup
```
npm install
```

### Run
```
node server.js
```

### RunDev
```
npm run dev 
```
### or
```
nodemon server.js
```
